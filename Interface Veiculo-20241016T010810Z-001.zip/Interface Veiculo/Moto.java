package com.company;

public class Moto implements Veiculo {
    public void darGrau(){
        System.out.println("A moto está dando grau.");
    }

    @Override
    public void acelerar() {

    }

    @Override
    public void frear() {

    }
}
