package com.company;

interface Veiculo {
    void acelerar();
    void frear();
}
